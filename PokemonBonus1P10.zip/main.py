from pokemon_game import*

main()
