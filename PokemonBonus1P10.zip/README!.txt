Hello - hope you're having a great day :)

When running the bonus activity please run the main.py file - thank you!